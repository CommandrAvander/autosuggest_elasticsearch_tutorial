module.exports = {
    url : 'http://localhost:9233',
    indexName : 'autosuggest'
}